function sensor_fusion_sfcn(block)
% S-Function for Drone Sensor Fusion (Gas + LiDAR via Mux)
%
% Inputs (vector u):
%   u(1) - Gas concentration (ppm)
%   u(2) - LiDAR distance (meters)
%
% Output:
%   y(1) - Risk index (0 = safe, 1 = critical)

  setup(block);

% -----------------------------
function setup(block)
  % Number of input/output ports
  block.NumInputPorts  = 1;   % Only 1 input port (vector)
  block.NumOutputPorts = 1;

  % Set input dimensions (2 elements: gas + lidar)
  block.SetPreCompInpPortInfoToDynamic;
  block.InputPort(1).Dimensions = 2;

  % Set output dimensions
  block.SetPreCompOutPortInfoToDynamic;
  block.OutputPort(1).Dimensions = 1;

  % Set sample time
  block.SampleTimes = [0.01 0];  % 10 ms step

  % Register methods
  block.RegBlockMethod('Outputs', @Outputs);

% -----------------------------
function Outputs(block)
  u = block.InputPort(1).Data;

  gas_ppm    = u(1);
  lidar_dist = u(2);

  % Example fusion logic:
  % Higher gas and closer obstacle = higher risk
  gas_weight   = min(gas_ppm/100, 1);        % normalize
  lidar_weight = max(0, (5 - lidar_dist)/5); % closer than 5m increases risk

  risk_index = (0.6*gas_weight + 0.4*lidar_weight);

  block.OutputPort(1).Data = risk_index;

