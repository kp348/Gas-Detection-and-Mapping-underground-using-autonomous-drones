function sensor_fusion_sfcn(block)
% S-Function for Drone Sensor Fusion
% Combines data from four sensors to calculate a real-time risk index.
%
% Inputs (vector u):
%   u(1) - MQ9 Gas Sensor (CO concentration in ppm)
%   u(2) - NIDAR Sensor (Distance in meters)
%   u(3) - AO-O2 Sensor (Oxygen level in %)
%   u(4) - Trieye Sensor (Assumed Visibility Risk, 0=clear to 1=obscured)
%
% Output (y):
%   y(1) - Fused Risk Index (0 = safe, 1 = critical)
  
  setup(block);
  
%endfunction

%
% The setup function is called when the S-function is initialized.
%
function setup(block)

  % Number of input and output ports
  block.NumInputPorts  = 1;   % One vector input from the Mux block
  block.NumOutputPorts = 1;

  % --- Configure the input port ---
  % The Mux block combines the 4 sensors into a single vector of 4 elements.
  block.SetPreCompInpPortInfoToDynamic;
  block.InputPort(1).Dimensions = 4;
  block.InputPort(1).DatatypeID  = 0; % double
  block.InputPort(1).Complexity  = 'Real';
  block.InputPort(1).DirectFeedthrough = true;

  % --- Configure the output port ---
  block.SetPreCompOutPortInfoToDynamic;
  block.OutputPort(1).Dimensions = 1;
  block.OutputPort(1).DatatypeID  = 0; % double
  block.OutputPort(1).Complexity  = 'Real';

  % Set the sample time. [-1 0] means it inherits from the driving block.
  block.SampleTimes = [-1 0];
  
  % Register the S-function's methods
  block.RegBlockMethod('Outputs', @Outputs);

%endfunction

%
% The Outputs function is called at each simulation step.
%
function Outputs(block)

  % --- Read Data from Input Vector ---
  u = block.InputPort(1).Data;
  mq9_gas_ppm     = u(1);
  nidar_distance  = u(2);
  o2_percent      = u(3);
  trieye_vis_risk = u(4);

  % --- Safety Thresholds ---
  CO_CRITICAL_PPM       = 50;   % Critical Carbon Monoxide level (ppm)
  DISTANCE_CRITICAL_M   = 1.0;  % Critical close distance (meters)
  O2_LOW_PERCENT        = 19.5; % OSHA oxygen deficiency level (%)

  % --- FUSION LOGIC ---
  
  % 1. Calculate individual risk factors (normalized from 0 to 1)
  
  % Gas risk: increases as CO approaches critical level
  gas_risk = min(mq9_gas_ppm / CO_CRITICAL_PPM, 1.0);
  
  % Distance risk: increases as drone gets closer than 5 meters
  dist_risk = max(0, (5 - nidar_distance) / 5);
  
  % Oxygen risk: increases as O2 drops below 19.5%
  % (Assumes 18% is a highly critical level for normalization)
  o2_risk = max(0, (O2_LOW_PERCENT - o2_percent) / (O2_LOW_PERCENT - 18.0));
  
  % Visibility risk: taken directly from the Trieye sensor input
  visibility_risk = min(max(trieye_vis_risk, 0), 1); % Ensure it's between 0 and 1

  % 2. Combine risks using a weighted average
  % Weights can be tuned based on mission priorities.
  % (Weights: Gas=40%, Distance=30%, Oxygen=20%, Visibility=10%)
  fused_risk = (0.4 * gas_risk) + ...
               (0.3 * dist_risk) + ...
               (0.2 * o2_risk) + ...
               (0.1 * visibility_risk);
  
  % 3. Apply critical safety overrides
  % If any of these conditions are met, the risk is immediately set to 1 (critical).
  if (mq9_gas_ppm > CO_CRITICAL_PPM) || ...
     (nidar_distance < DISTANCE_CRITICAL_M) || ...
     (o2_percent < O2_LOW_PERCENT)
    
      fused_risk = 1.0;
  end
  
  % Ensure final risk index is capped at 1.0
  fused_risk = min(fused_risk, 1.0);

  % --- Set the output value ---
  block.OutputPort(1).Data = fused_risk;
  
%endfunction